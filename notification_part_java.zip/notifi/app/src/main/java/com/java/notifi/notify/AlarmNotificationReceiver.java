package com.java.notifi.notify;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class AlarmNotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Boolean isPhoneLocked = isPhoneLocked(context);

        if("PUSH".equals(intent.getAction())){
            if(isPhoneLocked){
                setIsWaiting(context, true);
                Intent intentCheckScreen = new Intent(context, CheckStateScreenReceiver.class);
                context.startService(intentCheckScreen);
                Log.d("test", "AlarmNotificationReceiver: Wait unlock device to send AlertNotification");
            }else{
                Log.d("test", "AlarmNotificationReceiver: send");
                CleanAlertNotification cleanAlertNotification = new CleanAlertNotification();
                AlarmNotificationService alarmNotificationService = new AlarmNotificationService();

                cleanAlertNotification.setLastAlarmNotificationIsClosed(context, false);
                cleanAlertNotification.send(context, false);
                alarmNotificationService.updateSingleAlarm(context);
            }
        }

    }


    private void setIsWaiting(Context context, Boolean flag){
        SharedPreferences mSettings = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = mSettings.edit();

        editor.putBoolean("isWaiting", flag);
        editor.apply();
    }

    private Boolean isPhoneLocked(Context context){
        SharedPreferences mSettings = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE);

        return  mSettings.getBoolean("isLocked", false);
    }
}
