package com.java.notifi.notify;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.content.res.ResourcesCompat;

import com.java.notifi.MainActivity;
import com.java.notifi.R;

import java.util.Random;

public class CleanAlertNotification {
    private final String LAST_ALARM_NOTIFICATION_IS_CLOSED = "LAST_ALARM_NOTIFICATION_IS_CLOSED";
    private final String LAST_ALARM_NOTIFICATION_STYLE = "LAST_ALARM_NOTIFICATION_STYLE";
    private final String NOTIFICATION_STYLE_LAYOUT = "layoutRes";
    private final String NOTIFICATION_STYLE_TEXT = "textRes";
    private final int ALERT_PUSH_CODE = 999;

    public PendingIntent createOnDismissIntent(Context context, int notificationId){
        Intent intent = new Intent(context, NotificationDismissReceiver.class);
        intent.putExtra(" com.java.notifi:notificationId", notificationId);
        return PendingIntent.getBroadcast(context.getApplicationContext(), notificationId, intent, PendingIntent.FLAG_ONE_SHOT);
    }

    public Boolean getLastAlarmNotificationIsClosed(Context context){
        return context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE)
                .getBoolean(LAST_ALARM_NOTIFICATION_IS_CLOSED, true);
    }

    public int getLastAlarmNotificationStyleInt(Context context, String suffix){
        return context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE)
                .getInt(LAST_ALARM_NOTIFICATION_STYLE + suffix, 0);
    }

    public void setLastAlarmNotificationIsClosed(Context context, Boolean value){
        SharedPreferences.Editor editor = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE).edit();
        editor.putBoolean(LAST_ALARM_NOTIFICATION_IS_CLOSED, value);
        editor.apply();
    }

    public void setLastAlarmNotificationStyleInt(Context context, String suffix, int value) {
        if (!suffix.isEmpty()){
            SharedPreferences.Editor editor = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE).edit();
            editor.putInt(LAST_ALARM_NOTIFICATION_STYLE + suffix, value);
            editor.apply();
        }
    }

    public void send(Context context, Boolean resetLastStyle){
        int layoutRes;
        int textRes;

        if (resetLastStyle){
            int x = new Random().nextInt(3);
            if (x == 0){
                layoutRes = R.layout.alarm_notification_0;
            }else if(x == 1){
                layoutRes = R.layout.alarm_notification_1;
            }else{
                layoutRes = R.layout.alarm_notification_2;
            }
        }else{
            layoutRes = getLastAlarmNotificationStyleInt(context, NOTIFICATION_STYLE_LAYOUT);
        }

        if (resetLastStyle){
            int x = new Random().nextInt(3);
            if (x == 0){
                textRes = R.string.text_alarm_notification_1;
            }else if(x == 1){
                textRes = R.string.text_alarm_notification_2;
            }else{
                textRes = R.string.text_alarm_notification_3;
            }
        }else{
            textRes = getLastAlarmNotificationStyleInt(context, NOTIFICATION_STYLE_TEXT);
        }

        if (layoutRes == ResourcesCompat.ID_NULL || textRes == ResourcesCompat.ID_NULL){
            send(context, true);
            return;
        }

        Log.d("test", "NOTIFICATION_STYLE_LAYOUT=$layoutRes");
        Log.d("test", "NOTIFICATION_STYLE_TEXT=$textRes");

        setLastAlarmNotificationStyleInt(context, NOTIFICATION_STYLE_LAYOUT, layoutRes);
        setLastAlarmNotificationStyleInt(context, NOTIFICATION_STYLE_TEXT, textRes);

        Log.d("test", "Send AlertNotification, useLastStyle=$resetLastStyle");

        RemoteViews notificationLayout = new RemoteViews(context.getPackageName(), layoutRes);

        notificationLayout.setTextViewText(R.id.textNotify, context.getString(textRes));

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "FullScreenIntent")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(context.getString(R.string.app_name))
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setContent(notificationLayout)
                .setCustomContentView(notificationLayout)
                .setCustomBigContentView(notificationLayout)
                .setCustomHeadsUpContentView(notificationLayout)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAllowSystemGeneratedContextualActions(false)
                .setOngoing(true)
                .setAutoCancel(true)
                .setDeleteIntent(createOnDismissIntent(context, ALERT_PUSH_CODE))
                .setDefaults(NotificationCompat.DEFAULT_SOUND)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setFullScreenIntent(getFullScreenPendingIntent2(context), true)
                .setContentIntent(getFullScreenPendingIntent(context));


        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            buildChannel(notificationManager);
        }
        Notification notification = builder.build();
        notificationManager.notify(ALERT_PUSH_CODE, notification);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void buildChannel(NotificationManager notificationManager){
        NotificationChannel channel = new NotificationChannel(
                "FullScreenIntent",
                "FullScreenIntentChannel",
                NotificationManager.IMPORTANCE_HIGH);

        channel.setDescription( "This is used to demonstrate the Full Screen Intent");

        notificationManager.createNotificationChannel(channel);
    }

    public PendingIntent getFullScreenPendingIntent(Context context){
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("saved_isFirstInternalShown", true);

        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }


    public PendingIntent getFullScreenPendingIntent2(Context context){
        Intent intent = new Intent();
        intent.putExtra("saved_isFirstInternalShown", true);

        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

}
