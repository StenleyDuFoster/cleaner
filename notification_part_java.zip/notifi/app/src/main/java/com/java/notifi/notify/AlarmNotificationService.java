package com.java.notifi.notify;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.CallSuper;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.java.notifi.BuildConfig;
import com.java.notifi.MainActivity;
import com.java.notifi.R;

import java.util.Calendar;

public class AlarmNotificationService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);

        registerReceiver(new AlarmNotificationReceiver(), new IntentFilter("PUSH"));
        registerReceiver(new CheckStateScreenReceiver(), intentFilter);

        start(this);
        updateSingleAlarm(this);
    }

    public void start(Context context){

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "FullScreenIntent")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(context.getString(R.string.app_name))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setContentText("Service is running")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setWhen(0);

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            buildChannel(notificationManager);
        }
        Notification notification = builder.build();
        startForeground(1, notification);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void buildChannel(NotificationManager notificationManager){
        NotificationChannel channel = new NotificationChannel(
                    "FullScreenIntent",
                    "FullScreenIntentChannel",
                    NotificationManager.IMPORTANCE_HIGH);


        channel.setDescription( "This is used to demonstrate the Full Screen Intent");

        notificationManager.createNotificationChannel(channel);
    }

    public void updateSingleAlarm(Context context){
        Intent notifyIntent = new Intent(context, AlarmNotificationReceiver.class);
        notifyIntent.setAction("PUSH");

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, notifyIntent, 0);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        if (BuildConfig.DEBUG) {
            calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
            calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + 1);
        } else {
            calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY) + 2);
            calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
        }

        alarmManager.setExact(AlarmManager.RTC, calendar.getTimeInMillis(), pendingIntent);

        Log.d("test", "updateSingleAlarm to " + String.valueOf(calendar.getTimeInMillis()));
    }

}
