package com.java.notifi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.java.notifi.notify.AlarmNotificationService;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setLastAlarmNotificationIsClosed(this, true);
        startService(new Intent(this, AlarmNotificationService.class));
    }

    private void setLastAlarmNotificationIsClosed(Context context, Boolean value){
        SharedPreferences.Editor editor = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE).edit();
        editor.putBoolean("LAST_ALARM_NOTIFICATION_IS_CLOSED", value);
        editor.apply();
    }

}