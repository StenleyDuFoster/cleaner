package com.java.notifi.notify;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class CheckStateScreenReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Boolean isWaiting = getIsWaiting(context);

        if(intent.getAction().equals(Intent.ACTION_USER_PRESENT)){
            CleanAlertNotification cleanAlertNotification = new CleanAlertNotification();
            AlarmNotificationService alarmNotificationService = new AlarmNotificationService();
            if (isWaiting){
                Log.d("test", "CheckStateScreenReceiver: Send AlertNotification after waiting");
                setIsWaiting(context, false);
                cleanAlertNotification.setLastAlarmNotificationIsClosed(context, false);
                cleanAlertNotification.send(context, true);
                alarmNotificationService.updateSingleAlarm(context);
            } else {
                isPhoneLocked(context, false);
                if (!cleanAlertNotification.getLastAlarmNotificationIsClosed(context)) {
                    Log.d("test", "CheckStateScreenReceiver: Refresh notification");
                    cleanAlertNotification.setLastAlarmNotificationIsClosed(context, false);
                    cleanAlertNotification.send(context, false);
                }
            }
        }else if(intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
            isPhoneLocked(context, true);
        }

    }
    public void isPhoneLocked(Context context, Boolean flag){
        SharedPreferences mSettings = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = mSettings.edit();
        editor.putBoolean("isLocked", flag);
        editor.apply();

    }


    public Boolean getIsWaiting(Context context){
        SharedPreferences mSettings = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE);
        return mSettings.getBoolean("isWaiting", false);
    }

    public void setIsWaiting(Context context, Boolean flag){
        SharedPreferences mSettings = context.getSharedPreferences("NOTIFY_PRESENT", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = mSettings.edit();
        editor.putBoolean("isWaiting", flag);
        editor.apply();

    }
}
