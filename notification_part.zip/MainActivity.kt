package com.stenleone.clenner.ui.activity

import com.notif.AlarmNotificationService

class MainActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startService(Intent(this, AlarmNotificationService::class.java))
    }
}