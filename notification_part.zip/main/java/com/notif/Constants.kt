package com.notif

const val SEND_PUSH_ACTION = "PUSH"
const val NOTIFY_STORAGE = "NOTIFY_PRESENT"
const val NOTIFY_PERIOD_H = 2
const val NOTIFY_PERIOD_M = 0